<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="<?php echo esc_url(elevix_image('favicon.svg')); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header" id="site-header">
  <div class="nav-shell">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Elevix home">
      <img src="<?php echo esc_url(elevix_image('elevix-logo.png')); ?>" width="181" height="58" alt="Elevix">
    </a>
    <nav class="desktop-nav" aria-label="Main navigation">
      <div class="nav-dropdown-wrap" data-dropdown>
        <button class="nav-link" type="button" data-dropdown-trigger aria-expanded="false">Our Services <span class="nav-chevron">⌄</span></button>
        <div class="nav-dropdown service-megamenu" data-dropdown-panel hidden>
          <div class="nav-editorial-image" aria-hidden="true"><img src="<?php echo esc_url(elevix_image('glass-architecture.webp')); ?>" alt=""><span>CONNECTED THINKING.<br>GREATER POSSIBILITIES.</span></div>
          <?php foreach (elevix_services_data() as $slug=>$service): ?>
            <a href="<?php echo esc_url(home_url('/'.$slug.'/')); ?>"><span class="nav-service-icon"><?php echo elevix_simple_icon($service['theme']==='cloud'?'cloud':($service['theme']==='workplace'?'grid':($service['theme']==='product'?'phone':($service['theme']==='nextgen'?'layers':'sparkles'))),18); ?></span><span><?php echo esc_html($service['title']); ?></span><?php echo elevix_arrow_icon(15); ?></a>
          <?php endforeach; ?>
          <a href="<?php echo esc_url(home_url('/services/')); ?>"><span>Explore all services</span><?php echo elevix_arrow_icon(15); ?></a>
        </div>
      </div>
      <div class="nav-dropdown-wrap" data-dropdown>
        <button class="nav-link" type="button" data-dropdown-trigger aria-expanded="false">Company <span class="nav-chevron">⌄</span></button>
        <div class="nav-dropdown" data-dropdown-panel hidden>
          <a href="<?php echo esc_url(home_url('/overview/')); ?>"><span>Overview</span><?php echo elevix_arrow_icon(15); ?></a>
          <a href="<?php echo esc_url(home_url('/products/')); ?>"><span>Products</span><?php echo elevix_arrow_icon(15); ?></a>
          <a href="<?php echo esc_url(home_url('/careers/')); ?>"><span>Careers</span><?php echo elevix_arrow_icon(15); ?></a>
          <a href="<?php echo esc_url(home_url('/faq/')); ?>"><span>FAQ</span><?php echo elevix_arrow_icon(15); ?></a>
        </div>
      </div>
      <a class="nav-link" href="<?php echo esc_url(home_url('/case-studies/')); ?>">Case Studies</a>
      <a class="nav-link" href="<?php echo esc_url(home_url('/blogs/')); ?>">Blog</a>
    </nav>
    <a class="button button-dark nav-cta" href="<?php echo esc_url(home_url('/contact-us/')); ?>">Let’s Talk <?php echo elevix_arrow_icon(17); ?></a>
    <div class="mobile-nav">
      <button class="menu-button" type="button" data-mobile-trigger aria-expanded="false" aria-label="Open navigation"><span></span><span></span><span></span></button>
      <div class="mobile-menu-panel" data-mobile-panel hidden>
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        <a href="<?php echo esc_url(home_url('/services/')); ?>">Our Services</a>
        <?php foreach (elevix_services_data() as $slug=>$service): ?><a class="mobile-sub" href="<?php echo esc_url(home_url('/'.$slug.'/')); ?>"><?php echo esc_html($service['title']); ?></a><?php endforeach; ?>
        <a href="<?php echo esc_url(home_url('/overview/')); ?>">Overview</a>
        <a href="<?php echo esc_url(home_url('/products/')); ?>">Products</a>
        <a href="<?php echo esc_url(home_url('/case-studies/')); ?>">Case Studies</a>
        <a href="<?php echo esc_url(home_url('/blogs/')); ?>">Blog</a>
        <a href="<?php echo esc_url(home_url('/careers/')); ?>">Careers</a>
        <a href="<?php echo esc_url(home_url('/faq/')); ?>">FAQ</a>
        <a href="<?php echo esc_url(home_url('/contact-us/')); ?>">Let’s Talk</a>
      </div>
    </div>
  </div>
</header>

ELEVIX WORDPRESS THEME — INSTALLATION
=====================================

This is a custom WordPress conversion of the Elevix Next.js website. It is designed for standard WordPress/Managed WordPress hosting and does not require Node.js, npm or a build step.

WHAT IS INCLUDED
----------------
- Responsive Elevix homepage
- Sticky header with scroll-safe desktop dropdowns and mobile menu
- Company > Products navigation
- Services listing and five service detail pages
- AI & ML page with updated agentic AI / RAG / multimodal / governance content
- Next-Gen App Development with green-brand hero treatment
- Products listing and four product detail pages
  * Email Marketing Tool
  * Employee Attendance & Productivity Management App
  * eBook Library
  * Outreach Tool
- Overview, Careers, FAQ, Contact and Case Studies pages
- Native WordPress Blog listing + single post template
- Existing Elevix images and brand styling
- Updated Canada, Coimbatore and Madurai office addresses
- WordPress XML post import file in /import/elevix-posts.xml

SAFE INSTALL ON GODADDY MANAGED WORDPRESS
-----------------------------------------
1. Back up the current WordPress site first.
2. WordPress Admin > Appearance > Themes > Add New > Upload Theme.
3. Upload elevix-wp.zip and activate it.
4. On activation, the theme creates/reuses the required pages and assigns templates.
5. Visit Settings > Permalinks and click Save Changes once.
6. Check Settings > General and confirm the Administration Email Address.
7. If you want to import the supplied old Elevix blog posts:
   Tools > Import > WordPress > choose import/elevix-posts.xml.
8. Clear GoDaddy/WordPress cache after activation.

IMPORTANT
---------
- The theme does not delete existing pages or posts.
- If a page with the same slug already exists, the theme reuses it and assigns the Elevix template.
- Blog posts stay native WordPress posts.
- Contact form uses wp_mail(). For reliable production mail, configure the hosting mail service or an SMTP plugin.
- The desktop dropdown is pure JavaScript/CSS and does not use a modal scroll-lock, fixing the old header-disappearing-on-scroll problem.
- Core page layout/content is intentionally theme-controlled in this first conversion so the visual design stays stable. Blog content remains editable in WordPress. A later phase can expose more service/product content as custom fields without changing the UI.

MAIN URLS
---------
/
/overview/
/services/
/microsoft-365-services/
/ai-ml-services/
/smart-app-engineering/
/next-gen-app-development/
/cloud-services/
/products/
/products/email-marketing-tool/
/products/employee-productivity-app/
/products/ebook-library/
/products/outreach-tool/
/case-studies/
/blogs/
/careers/
/faq/
/contact-us/

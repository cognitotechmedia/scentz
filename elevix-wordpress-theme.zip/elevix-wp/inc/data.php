<?php
if (!defined('ABSPATH')) { exit; }

function elevix_services_data(): array {
    return [
        'microsoft-365-services' => [
            'title' => 'Microsoft 365 Solutions', 'short' => 'Microsoft 365', 'theme' => 'workplace', 'image' => 'm365-workplace.webp',
            'kicker' => 'THE CONNECTED WORKPLACE', 'outcome' => 'One workplace. Fewer workarounds.',
            'description' => 'Boost collaboration with Microsoft 365 tools.',
            'intro' => 'Bring documents, conversations and approvals into a connected Microsoft 365 environment. Make information easier to find and everyday work easier to complete.',
            'capabilities' => ['SharePoint intranets & document management','Power Apps & approval automation','Teams collaboration & integrations','Copilot readiness & information governance'],
            'diagramTitle' => 'How your workplace connects',
            'nodes' => [
                ['SharePoint','Structured content, document libraries and a trusted intranet.'],
                ['Teams','Conversations and access to the tools your people use.'],
                ['Power Platform','Forms, approvals and business process automation.'],
                ['Copilot readiness','Useful knowledge, appropriate permissions and clear guardrails.'],
            ],
            'sections' => [
                ['Find the right information.','Plan your information architecture, search experience and document ownership before moving files. A useful intranet starts with the questions employees actually ask.'],
                ['Move approvals out of inboxes.','Replace disconnected spreadsheets and email chains with role-based Power Apps and Power Automate workflows. Define exception handling and ownership alongside the happy path.'],
                ['Migrate with a plan.','Inventory your content, validate permissions, pilot the migration and agree a cutover strategy. Support people through the change with practical guidance and adoption sessions.'],
            ],
            'deliverables' => ['Tenant and content assessment','Intranet or application blueprint','Configured workflows and permissions','Migration validation and adoption guidance'],
            'faq' => [
                ['Can you work with our existing Microsoft 365 tenant?','Yes. The starting point is a review of the tenant, licensing, content structure and security requirements. The scope then builds on what you already have.'],
                ['Is Copilot automatically included?','No. Licensing, access controls and content readiness need to be assessed separately. We define what is suitable before an implementation.'],
            ],
        ],
        'ai-ml-services' => [
            'title' => 'AI & ML Services', 'short' => 'AI & ML', 'theme' => 'intelligence', 'image' => 'ml-intelligence.webp',
            'kicker' => 'AGENTIC AI. REAL WORKFLOWS. TRUSTED OUTCOMES.', 'outcome' => 'AI systems that reason, retrieve and take action safely.',
            'description' => 'Agentic AI, enterprise copilots, RAG systems and applied machine learning for modern business workflows.',
            'intro' => 'Move beyond AI demos and disconnected pilots. We design enterprise-ready copilots, retrieval systems, multimodal intelligence and action-oriented agents around your business data, tools and approval flows so teams can use AI with confidence.',
            'capabilities' => ['AI strategy, use-case discovery & roadmap design','Enterprise RAG, grounded search & knowledge copilots','Agentic workflows, tool integrations & human approvals','Multimodal AI, document intelligence & automation','Role-based copilots for business teams','LLMOps, evaluation, observability & optimization','Security, governance, privacy & responsible AI controls'],
            'diagramTitle' => 'A production AI system',
            'nodes' => [
                ['Ground','Connect governed documents, databases, APIs and multimodal business context.'],
                ['Reason','Use the right foundation model, retrieval strategy and structured workflow for the task.'],
                ['Act','Let agents call approved tools and automate bounded steps with least-privilege access.'],
                ['Evaluate','Measure accuracy, task success, safety, latency and cost against representative scenarios.'],
                ['Govern','Monitor behavior, permissions, feedback and drift with human review where it matters.'],
            ],
            'sections' => [
                ['Agentic AI that can complete useful work','Move from simple prompting to structured workflows where agents can gather context, call tools, draft outcomes, request approvals and complete bounded actions across your systems.'],
                ['Enterprise RAG and knowledge copilots','Ground answers in internal documents, policies, ticket history, databases and approved sources so users can trust what the system returns.'],
                ['Role-based copilots for operations, sales and support','Design copilots for specific teams with the prompts, context and actions that match the work they already do every day.'],
                ['Multimodal and document intelligence','Use AI to understand forms, screenshots, PDFs, contracts, support attachments and mixed media content. Combine extraction, classification and reasoning in one measurable workflow.'],
                ['AI automation with human approval layers','Use AI to draft, route and recommend actions while keeping people in control for sensitive or high-impact steps.'],
                ['LLMOps, evaluation and observability','Treat testing, telemetry, prompt iteration, guardrails and cost monitoring as product requirements so quality keeps improving after launch.'],
                ['Machine learning for forecasting, scoring and anomaly detection','Use traditional ML where prediction, scoring or pattern detection is the better fit, and combine it with modern AI interfaces when both add value.'],
                ['Governance, privacy and secure AI architecture','Design around sensitive data, access boundaries, redaction needs, auditability and human control. Responsible AI is part of the operating model from day one.'],
            ],
            'deliverables' => ['AI opportunity map and prioritized use-case roadmap','Grounded data, retrieval and model architecture','Prototype or proof of value for a copilot, agent or ML workflow','Integration design for business systems and approval steps','Evaluation, observability and security framework','Production rollout plan with quality, cost and adoption metrics'],
            'faq' => [
                ['Do we need to train our own AI model?','Usually not. Many enterprise AI solutions combine strong foundation models with retrieval, structured tools, workflow controls and evaluation. Custom training is only recommended when the use case, data volume and expected value clearly justify it.'],
                ['Can AI agents connect to our existing systems?','Yes. Agents can work with APIs, SaaS tools and internal platforms, but access should be explicitly scoped. Sensitive actions should include policy checks, human approval and audit logs.'],
                ['How do you reduce hallucinations and unreliable outputs?','We ground AI responses in trusted context, define representative test cases, monitor outputs in production and use structured responses, confidence checks or human review where risk is higher.'],
                ['How do we measure whether AI is actually delivering value?','We tie the solution to workflow metrics such as turnaround time, completion rate, agent deflection, quality, cost-to-serve or decision support accuracy.'],
            ],
        ],
        'smart-app-engineering' => [
            'title' => 'Smart App Engineering', 'short' => 'Smart apps', 'theme' => 'product', 'image' => 'product-glass.webp',
            'kicker' => 'WEB + MOBILE. ONE PRODUCT VISION.', 'outcome' => 'From a first tap to a lasting habit.',
            'description' => 'Custom mobile and web app development.',
            'intro' => 'Create web and mobile products around the tasks your customers need to complete. Align research, interface design and engineering around a focused release that can keep improving.',
            'capabilities' => ['Product discovery & interaction design','Responsive web applications','iOS, Android & cross-platform apps','API integration, testing & release engineering'],
            'diagramTitle' => 'A product journey, not a feature list',
            'nodes' => [['Understand','Interview users and map the task that matters.'],['Prototype','Test navigation and interactions before implementation.'],['Engineer','Build accessible interfaces with reliable APIs.'],['Release','Test critical journeys and ship with observability.']],
            'sections' => [['Web experiences with a clear purpose.','Build portals, dashboards and customer-facing platforms with usable navigation, accessible controls and purposeful performance budgets.'],['Mobile that fits the moment.','Design for real device conditions: interrupted connections, small screens and short sessions. Choose native or cross-platform engineering based on product needs, not a default.'],['A foundation your team can own.','Document the design system, API contracts and release process. Make the handover as intentional as the first prototype so your product can evolve after launch.']],
            'deliverables' => ['User journeys and interactive prototype','Reusable interface components','Tested web or mobile application','Release documentation and support handover'],
            'faq' => [['Do you build both web and mobile?','Yes. We can scope one platform or a connected web and mobile experience, with shared services where that makes sense.'],['Can you take over an existing application?','An initial code, dependency and architecture review identifies risks and helps define a practical improvement or delivery plan.']],
        ],
        'next-gen-app-development' => [
            'title' => 'Next-Gen App Development', 'short' => 'Next-gen apps', 'theme' => 'nextgen', 'image' => 'service-next.webp',
            'kicker' => 'INTELLIGENCE INSIDE THE EXPERIENCE', 'outcome' => 'Applications that do more than respond.',
            'description' => 'Intelligent solutions powered by machine learning.',
            'intro' => 'Bring intelligence into the product itself. Connect recommendations, contextual assistance and governed automation to real user journeys, with explicit limits on what the application can do.',
            'capabilities' => ['AI-native application architecture','Contextual assistants & recommendations','Event-driven workflows & integrations','Human-in-the-loop agent experiences'],
            'diagramTitle' => 'An intelligent action, with a control loop',
            'nodes' => [['Intent','The user asks for help with a defined task.'],['Context','The app retrieves permitted, relevant information.'],['Propose','A model suggests a response or action.'],['Approve','Policy checks or a person authorize the action.'],['Execute','An approved tool performs the bounded task.'],['Learn','Feedback informs the next evaluated release.']],
            'sections' => [['Contextual help, inside the workflow.','Give people assistance where they already work. Design clear references, recoverable errors and a straightforward route back to a human or standard interface.'],['Automation with boundaries.','Connect tools through limited permissions, action logs and approval steps. Sensitive actions should not depend on an unreviewed model response.'],['Modernize one useful experience at a time.','Add intelligent capabilities around existing services using well-defined APIs. Start with a contained user journey before expanding the application’s responsibilities.']],
            'deliverables' => ['AI interaction and permission model','Intelligent application prototype','Tool integration and approval flows','Evaluation suite and operational handover'],
            'faq' => [['How is this different from AI & ML Services?','AI & ML focuses on data, models and evaluation. Next-Gen App Development focuses on embedding those capabilities into a complete application and its user workflows.'],['Can an agent act without asking a user?','Only within explicitly agreed low-risk permissions. Sensitive or irreversible actions should require appropriate approval and an audit trail.']],
        ],
        'cloud-services' => [
            'title' => 'Cloud Services', 'short' => 'Cloud', 'theme' => 'cloud', 'image' => 'cloud-infrastructure.webp',
            'kicker' => 'A FOUNDATION FOR WHAT COMES NEXT', 'outcome' => 'Build resilience into every layer.',
            'description' => 'Secure and scalable cloud infrastructure solutions.',
            'intro' => 'Plan, migrate and operate cloud infrastructure with security, reliability and cost visibility in view. Match the platform to your workloads and the team responsible for running them.',
            'capabilities' => ['Cloud architecture & migration planning','Infrastructure as code & delivery pipelines','Identity, network & workload security','Observability, resilience & cost optimization'],
            'diagramTitle' => 'Your cloud operating foundation',
            'nodes' => [['Experience','Applications and APIs used by your customers and teams.'],['Workloads','Compute, containers and managed application services.'],['Data','Storage, databases, backup and recovery policies.'],['Foundation','Identity, networks, access boundaries and configuration.']],
            'sections' => [['A migration you can reason about.','Map application dependencies, assess the migration approach and define rollback steps. Pilot a representative workload before scheduling wider cutover waves.'],['Operations, built in.','Use repeatable infrastructure definitions and delivery pipelines. Set meaningful alerts, service objectives and ownership so teams can respond when something changes.'],['Make cost a design input.','Review resource sizing, idle capacity and usage patterns. Establish tagging and budget visibility rather than relying on a one-time optimization exercise.']],
            'deliverables' => ['Architecture and workload assessment','Migration waves and recovery plan','Infrastructure and deployment definitions','Monitoring, runbooks and cost visibility'],
            'faq' => [['Can we migrate in stages?','Yes. Dependency mapping and business constraints inform migration waves, pilot selection and rollback planning.'],['Does cloud automatically mean lower cost?','No. Cost depends on architecture, usage and operational decisions. We assess the trade-offs and establish visibility rather than promise a fixed saving.']],
        ],
    ];
}

function elevix_products_data(): array {
    return [
        'email-marketing-tool' => [
            'title'=>'Email Marketing Tool','short'=>'Email Marketing','eyebrow'=>'CONNECT. NURTURE. GROW.','image'=>'products/email-marketing-tool.svg',
            'description'=>'Create, automate, personalize and analyze professional email campaigns from one easy-to-use platform.',
            'intro'=>'Connect with your audience, build stronger relationships and drive measurable results. From campaign creation and contact management to automation, scheduling and analytics, the platform simplifies your complete email marketing journey.',
            'featuresTitle'=>'Everything you need to run smarter campaigns',
            'features'=>[['Professional Email Campaigns','Create attractive, responsive campaigns using customizable templates and intuitive design tools.'],['Contact & Audience Management','Organize contacts into lists and segments for more relevant communication.'],['Email Automation','Automate welcome emails, follow-ups, reminders and customer journeys based on schedules or triggers.'],['Personalized Communication','Use customer information to personalize greetings, offers and campaign content at scale.'],['Campaign Scheduling','Plan campaigns in advance and send at the right date and time.'],['Real-Time Analytics','Track deliveries, opens, clicks, bounces and unsubscribes to understand performance.'],['Campaign Performance Reports','Identify what works and continuously improve your email marketing strategy.'],['Responsive Email Design','Deliver a consistent experience across desktop, tablet and mobile devices.'],['Lead Nurturing','Build automated journeys that move prospects toward conversion with timely communication.']],
            'benefitsTitle'=>'Built to improve marketing efficiency','benefits'=>[['Reach customers directly','Stay connected with prospects and customers through their inbox.'],['Generate and nurture leads','Maintain consistent communication across the buyer journey.'],['Automate repetitive work','Save time while keeping campaigns active and relevant.'],['Measure what matters','Use actionable insights to improve engagement and results.']],
            'flow'=>['Create','Target','Automate','Send','Analyze','Grow'],'audience'=>[],
            'closingTitle'=>'Turn every email into an opportunity.','closingText'=>'Create smarter campaigns, connect with your audience and turn meaningful communication into measurable business growth.'
        ],
        'employee-productivity-app' => [
            'title'=>'Employee Attendance & Productivity Management App','short'=>'Productivity App','eyebrow'=>'TRACK ATTENDANCE. IMPROVE PERFORMANCE.','image'=>'products/productivity-app.svg',
            'description'=>'Track attendance, working hours, leave and productivity insights from one modern workforce platform.',
            'intro'=>'Give HR teams and managers real-time visibility into attendance, working hours, leave requests and productivity trends. Built for office, remote and multi-location teams, the app simplifies workforce administration while supporting better operational decisions.',
            'featuresTitle'=>'Workforce visibility from one dashboard','features'=>[['Smart Attendance Tracking','Record attendance through mobile or web check-ins with options for location-based attendance and secure authentication.'],['Working Hours Monitoring','Track login, logout, breaks, overtime and total working hours.'],['Employee Productivity Insights','Understand attendance patterns, active working hours, task progress and productivity trends.'],['Leave & Permission Management','Let employees request leave or permissions while managers review and approve quickly.'],['Real-Time Dashboard','See late arrivals, absences, working hours and productivity metrics at a glance.'],['Reports & Analytics','Generate daily, weekly and monthly reports for workforce planning.'],['Team & Employee Performance','Compare team-level trends, identify workload gaps and support data-driven performance discussions.'],['Secure & Reliable','Manage workforce data with reliable access and controlled visibility.']],
            'benefitsTitle'=>'Benefits to your business','benefits'=>[['Improve attendance & punctuality','Create better visibility and accountability across teams.'],['Reduce manual HR administration','Simplify routine attendance, leave and reporting tasks.'],['Identify productivity trends','Spot bottlenecks and patterns before they become bigger issues.'],['Make informed workforce decisions','Use real-time data to improve planning and operational efficiency.']],
            'flow'=>[],'audience'=>[],
            'closingTitle'=>'Empower your organization with better workforce visibility.','closingText'=>'Bring attendance, analytics and productivity insights together in one platform designed for modern workplaces.'
        ],
        'ebook-library' => [
            'title'=>'eBook Library','short'=>'eBooks','eyebrow'=>'LEARN. EXPLORE. GROW.','image'=>'products/ebook-library.svg',
            'description'=>'A growing collection of practical eBooks covering technology, business, digital marketing and professional growth.',
            'intro'=>'Explore insightful eBooks created to help businesses, professionals and technology enthusiasts learn, improve and stay ahead in a rapidly changing digital world. Each resource brings together practical knowledge, industry insights and expert perspectives in an easy-to-understand format.',
            'featuresTitle'=>'What you’ll find in our eBooks','features'=>[['Technology & Innovation','Discover technologies, digital trends, tools and innovations shaping modern businesses.'],['Business & Strategy','Learn practical approaches to growth, digital transformation, engagement and operational efficiency.'],['Digital Marketing','Explore strategies for building your online presence, reaching the right audience and growing your brand.'],['Emerging Technologies','Stay informed about AI, automation, cloud computing, software development and other transformative technologies.'],['Professional Development','Gain practical insights to improve skills, productivity and professional growth.']],
            'benefitsTitle'=>'Why read our eBooks?','benefits'=>[['Practical insights','Actionable knowledge you can apply to real-world situations.'],['Easy to understand','Complex topics explained in a simple and engaging way.'],['Industry relevant','Current trends, challenges and opportunities across technology and business.'],['Free resources','Valuable learning material designed to support better-informed decisions.']],
            'flow'=>[],'audience'=>[],
            'closingTitle'=>'Knowledge that helps you grow.','closingText'=>'Build your understanding, discover new opportunities and keep learning with practical resources from Elevix.'
        ],
        'outreach-tool' => [
            'title'=>'Outreach Tool','short'=>'Outreach','eyebrow'=>'TURN EVERY EMAIL INTO AN OPPORTUNITY','image'=>'products/outreach-tool.svg',
            'description'=>'Connect with customers, nurture leads and manage targeted outreach with automation, segmentation and analytics.',
            'intro'=>'From creating professional campaigns to managing contacts, automating follow-ups and tracking performance, our Outreach Tool gives you everything you need to engage the right audience at the right time.',
            'featuresTitle'=>'Powerful outreach made simple','features'=>[['Professional Email Campaigns','Create engaging campaigns using customizable templates and an intuitive campaign builder.'],['Contact & Audience Management','Organize contacts into lists and segments for relevant, targeted messaging.'],['Targeted Campaigns','Reach customer groups based on interests, behavior, demographics or other criteria.'],['Email Automation','Automate welcome emails, follow-ups, reminders and recurring communications.'],['Real-Time Campaign Analytics','Monitor deliveries, opens, clicks, bounces and unsubscribes.'],['Drip Campaigns','Build automated sequences that nurture prospects through the customer journey.'],['Easy Integration','Connect with your website, CRM, applications and business tools.'],['Responsive Email Templates','Create messages that look professional across desktop, tablet and mobile.'],['Secure & Reliable','Manage contacts and campaigns with confidence using a reliable platform foundation.']],
            'benefitsTitle'=>'Why choose our Outreach Tool?','benefits'=>[['Save time','Automate repetitive marketing activities and focus on growing your business.'],['Reach the right audience','Use segmentation and targeting to deliver more relevant communication.'],['Improve customer engagement','Build personalized campaigns that keep customers connected with your brand.'],['Grow your business','Convert leads, retain customers and create long-term relationships.']],
            'audience'=>['Small & Medium Businesses','Startups','E-commerce Businesses','Marketing Agencies','Sales Teams','Service Businesses','Educational Institutions','Real Estate Companies','Corporate & Enterprise Teams'],
            'flow'=>['Create','Target','Automate','Send','Analyze','Grow'],
            'closingTitle'=>'Ready to make your outreach more effective?','closingText'=>'Build stronger customer relationships, generate more leads and accelerate growth with smarter, more consistent communication.'
        ],
    ];
}

function elevix_case_studies_data(): array {
    return [
        'employee-super-app'=>['client'=>'People.','label'=>'AI AGENTS & AUTOMATION','title'=>'AI Agents Powering an Employee Super App','description'=>'An employee super app powered by AI agents, with 300 hours saved per month and a 60% reduction in HR and IT service desk tickets.','tools'=>['AI Agents','Employee Experience'],'image'=>'ai-glass.webp','metric'=>'300 hours','metric_note'=>'saved per month'],
        'intelligent-ebook-management'=>['client'=>'Publish.','label'=>'INTELLIGENT WORKFLOWS','title'=>'Intelligent Ebook Management','description'=>'Parallel workflows that support a five-times faster ebook turnaround, helping teams move work forward together.','tools'=>['Automation','Parallel Workflows'],'image'=>'product-glass.webp','metric'=>'5× faster','metric_note'=>'ebook turnaround'],
        'microsoft-365-migration'=>['client'=>'Connect.','label'=>'MICROSOFT 365 MIGRATION','title'=>'Google Workspace to Microsoft 365 Migration','description'=>'A move from Google Workspace to Microsoft 365 with 99.9% mailbox migration accuracy.','tools'=>['Microsoft 365','Cloud Migration'],'image'=>'service-cloud.webp','metric'=>'99.9%','metric_note'=>'mailbox migration accuracy'],
    ];
}

function elevix_faq_data(): array {
    return [
        ['What services does Elevix provide?','We work across Microsoft 365 Solutions, AI & ML Services, Smart App Engineering, Next-Gen App Development, and Cloud Services. We can help with a focused project or a broader digital transformation.'],
        ['Do you work with startups and enterprises?','Yes. Our approach adapts to the stage of your business, from defining a first product to improving the platforms an established team relies on.'],
        ['Can you improve our existing applications?','Yes. Application modernization starts with understanding your existing systems, business requirements, and constraints. Together we can identify a practical path for improvements and migration.'],
        ['How do we get started?','Tell us about your idea, the problem you want to solve, and where you are today. We’ll use an initial conversation to understand your goals and discuss the next steps.'],
        ['Can you help with Microsoft 365 and automation?','Yes. We develop solutions using SharePoint, Teams, Power Apps, and Power Automate, and help businesses explore useful applications of Microsoft Copilot.'],
    ];
}

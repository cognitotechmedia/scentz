<?php
if (!defined('ABSPATH')) { exit; }

function elevix_asset(string $path = ''): string {
    return trailingslashit(get_template_directory_uri()) . 'assets/' . ltrim($path, '/');
}

function elevix_image(string $path): string {
    return elevix_asset('images/' . ltrim($path, '/'));
}

function elevix_arrow_icon(int $size = 18): string {
    $s = max(12, min(64, $size));
    return '<svg width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
}

function elevix_check_icon(int $size = 18): string {
    $s = max(12, min(48, $size));
    return '<svg width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12 4 4L19 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
}

function elevix_simple_icon(string $name, int $size = 24): string {
    $s = max(14, min(64, $size));
    $common = 'width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" aria-hidden="true"';
    $stroke = 'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"';
    $paths = [
        'sparkles' => '<path d="m12 3 1.2 3.6L17 8l-3.8 1.4L12 13l-1.2-3.6L7 8l3.8-1.4L12 3Z" '.$stroke.'/><path d="m18 14 .7 2.1L21 17l-2.3.9L18 20l-.7-2.1L15 17l2.3-.9L18 14ZM5 13l.8 2.4L8 16l-2.2.8L5 19l-.8-2.2L2 16l2.2-.6L5 13Z" '.$stroke.'/>',
        'layers' => '<path d="m12 3 8 4-8 4-8-4 8-4Z" '.$stroke.'/><path d="m4 12 8 4 8-4M4 17l8 4 8-4" '.$stroke.'/>',
        'shield' => '<path d="M12 3 5 6v5c0 4.6 2.9 8 7 10 4.1-2 7-5.4 7-10V6l-7-3Z" '.$stroke.'/><path d="m9 12 2 2 4-5" '.$stroke.'/>',
        'code' => '<path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14" '.$stroke.'/>',
        'grid' => '<rect x="4" y="4" width="6" height="6" rx="1" '.$stroke.'/><rect x="14" y="4" width="6" height="6" rx="1" '.$stroke.'/><rect x="4" y="14" width="6" height="6" rx="1" '.$stroke.'/><rect x="14" y="14" width="6" height="6" rx="1" '.$stroke.'/>',
        'cloud' => '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6.2 8.2 4.5 4.5 0 0 0 7 18Z" '.$stroke.'/>',
        'phone' => '<rect x="7" y="2.5" width="10" height="19" rx="2" '.$stroke.'/><path d="M10 5h4M11 18h2" '.$stroke.'/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2" '.$stroke.'/><path d="m4 7 8 6 8-6" '.$stroke.'/>',
        'map' => '<path d="M12 21s6-5.2 6-11a6 6 0 1 0-12 0c0 5.8 6 11 6 11Z" '.$stroke.'/><circle cx="12" cy="10" r="2" '.$stroke.'/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8" '.$stroke.'/>',
        'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20V7" '.$stroke.'/>',
        'clock' => '<circle cx="12" cy="12" r="9" '.$stroke.'/><path d="M12 7v5l3 2" '.$stroke.'/>',
        'book' => '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v16H6.5A2.5 2.5 0 0 0 4 21.5v-16ZM20 5.5A2.5 2.5 0 0 0 17.5 3H13v16h4.5a2.5 2.5 0 0 1 2.5 2.5v-16Z" '.$stroke.'/>',
    ];
    $content = $paths[$name] ?? $paths['sparkles'];
    return '<svg '.$common.'>'.$content.'</svg>';
}

function elevix_page_intro(string $eyebrow, string $title, string $description, string $image = 'product-glass.webp'): void {
    ?>
    <section class="page-intro container">
      <div class="breadcrumb"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a><span>/</span><?php echo esc_html($eyebrow); ?></div>
      <div class="page-intro-grid">
        <div class="page-intro-copy">
          <span class="eyebrow"><span class="status-dot"></span><?php echo esc_html($eyebrow); ?></span>
          <h1><?php echo esc_html($title); ?></h1>
          <p><?php echo esc_html($description); ?></p>
          <span class="page-intro-line"></span>
        </div>
        <div class="page-intro-visual" data-reveal>
          <img src="<?php echo esc_url(elevix_image($image)); ?>" alt="<?php echo esc_attr($eyebrow); ?> visual" loading="eager">
          <span class="page-visual-index">E / <?php echo esc_html(strtoupper($eyebrow)); ?></span>
          <span class="page-visual-arrow"><?php echo elevix_arrow_icon(30); ?></span>
        </div>
      </div>
    </section>
    <?php
}

function elevix_cta(): void {
    ?>
    <section class="container cta-wrap">
      <div class="cta-panel" data-reveal>
        <div>
          <span class="eyebrow"><span class="status-dot"></span>LET’S BUILD SOMETHING THAT MATTERS</span>
          <h2>Got a bold vision?<br>Let’s bring it to life.</h2>
          <p>Your next chapter starts with a conversation.</p>
        </div>
        <a href="<?php echo esc_url(home_url('/contact-us/')); ?>" class="button button-dark">Talk to our experts <?php echo elevix_arrow_icon(19); ?></a>
        <img class="cta-glass-image" src="<?php echo esc_url(elevix_image('product-glass.webp')); ?>" alt="" loading="lazy">
        <span class="cta-watermark" aria-hidden="true">↗</span>
      </div>
    </section>
    <?php
}

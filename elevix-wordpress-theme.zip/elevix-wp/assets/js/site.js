(() => {
  const q = (s, r=document) => r.querySelector(s);
  const qa = (s, r=document) => [...r.querySelectorAll(s)];

  const closeDropdowns = (except=null) => {
    qa('[data-dropdown]').forEach(wrap => {
      if (wrap === except) return;
      const btn=q('[data-dropdown-trigger]',wrap), panel=q('[data-dropdown-panel]',wrap);
      wrap.classList.remove('is-open'); if(panel) panel.hidden=true; if(btn) btn.setAttribute('aria-expanded','false');
    });
  };
  qa('[data-dropdown]').forEach(wrap => {
    const btn=q('[data-dropdown-trigger]',wrap), panel=q('[data-dropdown-panel]',wrap);
    if(!btn || !panel) return;
    btn.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      const opening = panel.hidden;
      closeDropdowns(wrap);
      panel.hidden = !opening;
      wrap.classList.toggle('is-open', opening);
      btn.setAttribute('aria-expanded', opening ? 'true' : 'false');
    });
  });
  document.addEventListener('click', e => { if(!e.target.closest('[data-dropdown]')) closeDropdowns(); });
  document.addEventListener('keydown', e => { if(e.key==='Escape') closeDropdowns(); });

  const mobileBtn=q('[data-mobile-trigger]'), mobilePanel=q('[data-mobile-panel]');
  if(mobileBtn && mobilePanel){
    mobileBtn.addEventListener('click',()=>{
      const open=mobilePanel.hidden; mobilePanel.hidden=!open; mobileBtn.setAttribute('aria-expanded',open?'true':'false'); document.body.classList.toggle('mobile-menu-open',open);
    });
    qa('a',mobilePanel).forEach(a=>a.addEventListener('click',()=>{mobilePanel.hidden=true; mobileBtn.setAttribute('aria-expanded','false'); document.body.classList.remove('mobile-menu-open');}));
  }

  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } });
  }, {threshold:.08, rootMargin:'0px 0px -28px 0px'}) : null;
  qa('[data-reveal], .service-card, .case-card, .post-card, .inner-visual-card').forEach(el => observer ? observer.observe(el) : el.classList.add('is-visible'));

  qa('[data-tabs]').forEach(root => {
    const buttons=qa('[data-tab]',root), panels=qa('[data-panel]',root);
    const activate=(id)=>{buttons.forEach(b=>{const active=b.dataset.tab===id;b.classList.toggle('active',active);b.setAttribute('aria-selected',active?'true':'false')});panels.forEach(p=>p.hidden=p.dataset.panel!==id)};
    buttons.forEach(b=>b.addEventListener('click',()=>activate(b.dataset.tab)));
    if(buttons[0]) activate(buttons[0].dataset.tab);
  });

  const slides=qa('[data-hero-slide]'), selectors=qa('[data-hero-select]');
  if(slides.length){
    let current=0, timer;
    const show=(i)=>{current=(i+slides.length)%slides.length;slides.forEach((s,n)=>{s.hidden=n!==current;s.classList.toggle('slide-active',n===current)});selectors.forEach((b,n)=>b.classList.toggle('selected',n===current));};
    const start=()=>{clearInterval(timer);timer=setInterval(()=>show(current+1),6500)};
    selectors.forEach((b,i)=>b.addEventListener('click',()=>{show(i);start()}));
    show(0); start();
    const hero=q('.hero-v2'); if(hero){hero.addEventListener('mouseenter',()=>clearInterval(timer));hero.addEventListener('mouseleave',start)}
  }

  qa('[data-count]').forEach(el=>{
    const end=Number(el.dataset.count||0), suffix=el.dataset.suffix||''; let done=false;
    const run=()=>{if(done)return;done=true;const start=performance.now();const tick=t=>{const p=Math.min(1,(t-start)/1100);el.textContent=Math.round(end*(1-Math.pow(1-p,3)))+suffix;if(p<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)};
    if('IntersectionObserver' in window){new IntersectionObserver(([e],o)=>{if(e.isIntersecting){run();o.disconnect()}},{threshold:.4}).observe(el)} else run();
  });
})();

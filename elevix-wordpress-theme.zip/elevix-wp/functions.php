<?php
if (!defined('ABSPATH')) { exit; }
require_once get_template_directory() . '/inc/data.php';
require_once get_template_directory() . '/inc/helpers.php';

function elevix_theme_setup(): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
    add_theme_support('custom-logo', ['height'=>58,'width'=>181,'flex-height'=>true,'flex-width'=>true]);
    register_nav_menus(['primary'=>__('Primary Navigation','elevix'),'footer'=>__('Footer Navigation','elevix')]);
}
add_action('after_setup_theme','elevix_theme_setup');

function elevix_enqueue_assets(): void {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('elevix-fonts','https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;450;500;550;600;650;700&family=Manrope:wght@400;500;600;650;700;750;800&display=swap',[],null);
    wp_enqueue_style('elevix-site', get_template_directory_uri().'/assets/css/site.css', ['elevix-fonts'], $version);
    wp_enqueue_style('elevix-wp', get_template_directory_uri().'/assets/css/wordpress.css', ['elevix-site'], $version);
    wp_enqueue_script('elevix-site', get_template_directory_uri().'/assets/js/site.js', [], $version, true);
}
add_action('wp_enqueue_scripts','elevix_enqueue_assets');

function elevix_excerpt_length(): int { return 24; }
add_filter('excerpt_length','elevix_excerpt_length',999);

function elevix_create_page(string $title, string $slug, string $template = 'default', int $parent = 0): int {
    $existing = get_page_by_path($parent ? get_post_field('post_name',$parent).'/'.$slug : $slug, OBJECT, 'page');
    if ($existing) {
        $id = (int)$existing->ID;
    } else {
        $id = wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$title,'post_name'=>$slug,'post_parent'=>$parent]);
    }
    if ($id && !is_wp_error($id) && $template !== 'default') update_post_meta($id,'_wp_page_template',$template);
    return is_wp_error($id) ? 0 : (int)$id;
}

function elevix_seed_pages(): void {
    $home = elevix_create_page('Home','home');
    elevix_create_page('Overview','overview','page-overview.php');
    elevix_create_page('Our Services','services','page-services.php');
    elevix_create_page('Careers','careers','page-careers.php');
    elevix_create_page('FAQ','faq','page-faq.php');
    elevix_create_page('Contact Us','contact-us','page-contact-us.php');
    $cases = elevix_create_page('Case Studies','case-studies','page-case-studies.php');
    $products = elevix_create_page('Products','products','page-products.php');
    foreach (elevix_services_data() as $slug=>$service) elevix_create_page($service['title'],$slug,'template-service.php');
    foreach (elevix_products_data() as $slug=>$product) elevix_create_page($product['title'],$slug,'template-product.php',$products);
    foreach (elevix_case_studies_data() as $slug=>$case) elevix_create_page($case['title'],$slug,'template-case-study.php',$cases);
    $blogs = elevix_create_page('Blogs','blogs');
    if ($home) { update_option('show_on_front','page'); update_option('page_on_front',$home); }
    if ($blogs) update_option('page_for_posts',$blogs);
    update_option('permalink_structure','/blogs/%postname%/');
    flush_rewrite_rules(false);
}
add_action('after_switch_theme','elevix_seed_pages');

function elevix_contact_submit(): void {
    if (!isset($_POST['elevix_contact_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['elevix_contact_nonce'])),'elevix_contact')) {
        wp_safe_redirect(add_query_arg('contact','error',home_url('/contact-us/'))); exit;
    }
    $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $company = sanitize_text_field(wp_unslash($_POST['company'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
    if (!$name || !is_email($email) || !$message) { wp_safe_redirect(add_query_arg('contact','error',home_url('/contact-us/'))); exit; }
    $to = get_option('admin_email');
    $subject = 'Elevix website enquiry from '.$name;
    $body = "Name: {$name}\nEmail: {$email}\nCompany: {$company}\n\nMessage:\n{$message}";
    $headers = ['Reply-To: '.$name.' <'.$email.'>'];
    $ok = wp_mail($to,$subject,$body,$headers);
    wp_safe_redirect(add_query_arg('contact',$ok?'sent':'error',home_url('/contact-us/'))); exit;
}
add_action('admin_post_nopriv_elevix_contact','elevix_contact_submit');
add_action('admin_post_elevix_contact','elevix_contact_submit');

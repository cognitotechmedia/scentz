<footer class="site-footer">
  <div class="container footer-brand-stage" data-reveal>
    <span>YOUR NEXT CHAPTER STARTS WITH</span>
    <img src="<?php echo esc_url(elevix_image('elevix-wordmark.svg')); ?>" alt="Elevix" width="70" height="22">
    <a href="<?php echo esc_url(home_url('/contact-us/')); ?>" aria-label="Start your next chapter with Elevix"><?php echo elevix_arrow_icon(48); ?></a>
  </div>
  <div class="container footer-top">
    <div class="footer-brand">
      <a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(elevix_image('elevix-logo.png')); ?>" width="140" height="45" alt="Elevix"></a>
      <p>Good ideas deserve<br>a great technology partner.</p>
      <a href="mailto:sales@elevixtech.com" class="text-link">sales@elevixtech.com <?php echo elevix_arrow_icon(17); ?></a>
    </div>
    <div><h3>Our Services</h3><?php foreach(elevix_services_data() as $slug=>$service): ?><a href="<?php echo esc_url(home_url('/'.$slug.'/')); ?>"><?php echo esc_html($service['title']); ?></a><?php endforeach; ?></div>
    <div><h3>Company</h3><a href="<?php echo esc_url(home_url('/overview/')); ?>">Overview</a><a href="<?php echo esc_url(home_url('/products/')); ?>">Products</a><a href="<?php echo esc_url(home_url('/case-studies/')); ?>">Case Studies</a><a href="<?php echo esc_url(home_url('/careers/')); ?>">Careers</a><a href="<?php echo esc_url(home_url('/faq/')); ?>">FAQ</a><a href="<?php echo esc_url(home_url('/blogs/')); ?>">Blog</a></div>
    <div class="footer-address">
      <h3>Our offices</h3>
      <p><strong>Registered Office – Canada</strong><br>201–6660 Kennedy Road<br>Mississauga, Ontario<br>L5T 2M9, Canada</p>
      <p><strong>Coimbatore</strong><br>47/1A – Sreesha Building<br>Dhanalakshmipuram, Singanallur<br>Coimbatore – 641005</p>
      <p><strong>Madurai</strong><br>63, Teachersline Colony<br>Pasumalai, Madurai – 625004</p>
      <a class="text-link" href="<?php echo esc_url(home_url('/contact-us/')); ?>">Start a conversation <?php echo elevix_arrow_icon(17); ?></a>
    </div>
  </div>
  <div class="container footer-bottom"><span>© <?php echo esc_html(wp_date('Y')); ?> Elevix. All rights reserved.</span><span>Ideas into impact. Together.</span><a href="#top">Back to top ↑</a></div>
</footer>
<?php wp_footer(); ?>
</body></html>
